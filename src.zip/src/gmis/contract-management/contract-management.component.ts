import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contract-management',
  templateUrl: './contract-management.component.html',
  styleUrls: ['./contract-management.component.css']
})
export class ContractManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
