import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wua-information',
  templateUrl: './wua-information.component.html',
  styleUrls: ['./wua-information.component.css']
})
export class WuaInformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
