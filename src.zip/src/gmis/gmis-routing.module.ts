import { LocationComponent } from './location/location.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GmisComponent } from './gmis.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { InformationComponent } from './information/information.component';
import { ProjectDataGuardService } from './project-data-gurad.service';
import { AppRouteGuard } from '@shared/auth/auth-route-guard';

const routes: Routes = [
  {
    path: '',
    component: GmisComponent,
    children: [
      // { path: '', redirectTo: '/gmis/dashboard', pathMatch: 'full' },
      { path: 'dashboard', component: DashboardComponent, canActivate: [AppRouteGuard] },
      // { path: 'information', component: InformationComponent, },
      { path: 'information', component: InformationComponent, data: {  }, canActivate: [ProjectDataGuardService] },
      { path: 'location', component: LocationComponent, data: {  }, canActivate: [ProjectDataGuardService] },
      

    ]
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GmisRoutingModule { }
